package com.example.shen.sqlitetest.entity;

/**
 * Created by SHEN on 2015/12/17.
 */
public class User {
    public String username;
    public String password;
}
